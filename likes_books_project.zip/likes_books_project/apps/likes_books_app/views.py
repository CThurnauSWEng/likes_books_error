from django.shortcuts import render, HttpResponse, redirect
from .models import Book, User

# Create your views here.
def index(request):
    User.objects.all().delete()
    Book.objects.all().delete()

    # create a user and a book and associate the book as having been uploaded by the user
    User.objects.create(first_name="Carrie",last_name="Thurnau",email="kaylee@love.com")
    carrie = User.objects.last()
    Book.objects.create(name="Dog Training",desc="A very useful book",uploader=carrie)
    carrie_b1 = Book.objects.last()
    Book.objects.create(name="More Dog Training",desc="Another very useful book",uploader=carrie)
    carrie_b2 = Book.objects.last()
    all_carries_books = carrie.uploaded_books.all()
    print "Carrie's books"
    for carrie_book in all_carries_books:
        print carrie_book.name
    print "************"

    # do another
    User.objects.create(first_name="Jeff",last_name="Thurnau",email="kaylee1@love.com")
    jeff = User.objects.last()
    Book.objects.create(name="Tesla Model 2",desc="Reviews and feature discussion",uploader=jeff)
    jeff_b1 = Book.objects.last()
    Book.objects.create(name="Telsa Model 3",desc="Pros and Cons of model 3",uploader=jeff)
    jeff_b2 = Book.objects.last()

    # do another
    User.objects.create(first_name="Kaylee",last_name="Lady-Bear",email="kaylee2@love.com")
    kaylee = User.objects.last()
    Book.objects.create(name="The Art of Eating Breakfast",desc="Importance of kibble and veggies",uploader=kaylee)
    kaylee_b1 = Book.objects.last()
    Book.objects.create(name="How to Train Your Owner",desc="Covers whining, begging, soulful eyes",uploader=kaylee)
    kaylee_b2 = Book.objects.last()

    # now have three users, each have uploaded two books
    all_books = Book.objects.all()
    for book in all_books:
        print "book: ", book.name
        print "book.uploader: ", book.uploader.first_name

    print "************"
    all_users = User.objects.all()
    for user in all_users:
        print "user: ", user.first_name
        uploaded_books = user.uploaded_books.all()
        for upbook in uploaded_books:
            print upbook.name

    print "******* Change name of Kaylee's Breakfast book *****"
    all_kaylees_books = kaylee.uploaded_books.all()
    print "Kaylees's books"
    for kaylee_book in all_kaylees_books:
        if kaylee_book.name == "The Art of Eating Breakfast":
            print "Before: ", kaylee_book.name
            kaylee_book.name = "The Art of Eating"
            print "After: ", kaylee_book.name

        
    # This is the one I can't figure out:

    # Have the first user like the last book and the first book
    last_book = Book.objects.last()
    print last_book.name
    print carrie.first_name
    last_book.liked_users.add(carrie)
    print "**** last_book's liked users: ", last_book.liked_users

    # this prints out:
    # **** last_book's liked users:  likes_books_app.User.None
    


    context = {
        "books" : Book.objects.all(),
        "users" : User.objects.all()
    }

    return render (request, "likes_books_app/index.html", context)

